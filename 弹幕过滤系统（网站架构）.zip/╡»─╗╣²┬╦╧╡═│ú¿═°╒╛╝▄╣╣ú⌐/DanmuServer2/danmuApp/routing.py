from django.urls import path
from django.conf.urls import url
from . import consumers
danmu_websocket_routing=[
    path('danmu_resolution/',consumers.DanmuConsumer)
]