from DanmuServer.settings import BASE_DIR
import os
dirty_txt_path=os.path.join(BASE_DIR,"danmuApp/danmuFilter/dirty_dict.txt")
huyajs_path=os.path.join(BASE_DIR,"danmuApp/danmuHook/huyaDanmuHook/test.js")
douyuHook_path=os.path.join(BASE_DIR,"danmuApp/danmuHook/douyuDanmuHook.py")
dirty_code_path=os.path.join(BASE_DIR,"danmuApp/danmuFilter/percentFilterMethod/dirty_code.txt")