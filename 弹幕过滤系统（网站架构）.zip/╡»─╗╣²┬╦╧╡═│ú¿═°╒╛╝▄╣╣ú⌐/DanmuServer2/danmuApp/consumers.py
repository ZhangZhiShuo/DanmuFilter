
import danmuApp.pathconfig
from danmuApp.workingStruct import workingStruct
from danmuApp.danmuHook import douyuDanmuHook,quanminDanmuHook,zhanqiDanmuHook,bilibiliDanmuHook,xiongmaoDanmuHook,xiongmaoxingxiuDanmuHook
from danmuApp.danmuHook.huyaDanmuHook import huyaDanmuHook
import threading
from asgiref.sync import async_to_sync
import re
from channels.generic.websocket import WebsocketConsumer
import json
import time
import danmuApp.pathconfig
import subprocess
class DanmuConsumer(WebsocketConsumer):
    def connect(self):
        #print(self.scope)
        #self.currentUrl=""
        self.accept()
        print("连接已经建立")
    def disconnect(self, code):
        print("连接请求关闭")
        self.disconnecthandler()

    def receive(self, text_data=None, bytes_data=None):
        # print(text_data)
        #time.sleep(100)
        self.dataHandler(text_data)
    def group_message(self,event):
        #print(event)
        message=event["message"]
        self.send(text_data=message)
    def disconnecthandler(self):
        async_to_sync(self.channel_layer.group_discard)(
            workingStruct[self.currentUrl]["groupName"],
            self.channel_name
        )
        workingStruct[self.currentUrl]["count"] -= 1
        if workingStruct[self.currentUrl]["count"]==0:
            workingStruct[self.currentUrl]["processRun"]=False
            #time.sleep(1)
           # workingStruct.pop(self.currentUrl)
        print("关闭处理函数完毕")

    def dataHandler(self,data):
        json_data = json.loads(data)
        self.type = json_data['hooktype']
        self.currentUrl = json_data['url']
        if self.currentUrl in workingStruct and workingStruct.get(self.currentUrl).get("count")>0:#如果工作目录中存在这个url 则直接入组接收消息即可，不用另开一个线程
                workingStruct[self.currentUrl]["count"]+=1#此url用户数加一，到零时关闭这个url的处理线程
                async_to_sync(self.channel_layer.group_add)(
                    workingStruct[self.currentUrl]["groupName"],
                    self.channel_name,
                )
        else:
                if self.currentUrl not in workingStruct:#创建一个新url的工作目录
                   workingStruct[self.currentUrl]={}
                workingStruct[self.currentUrl]["count"]=1
                self.groupName=re.sub('[’!"#$%&\'()*,-./:;<=>?@，。?★、…【】《》？“”‘’！[\\]^_`{|}~\s]+', "_", self.currentUrl)
                workingStruct[self.currentUrl]["groupName"]=self.groupName
                async_to_sync(self.channel_layer.group_add)(
                        self.groupName,
                        self.channel_name,
                    )
                print("Group name is %s" %self.groupName)
                workingStruct[self.currentUrl]["process"] = threading.Thread(target=self.threadrun,args=(self.type,self.currentUrl))#新增处理线程
                workingStruct[self.currentUrl]["processRun"]=True
                workingStruct[self.currentUrl]["process"].start()
                print(workingStruct[self.currentUrl]["groupName"] + "  thread: "+workingStruct[self.currentUrl]["process"].getName()+" start")


    def threadrun(self,type,url):
        if type=="douyu":
            douyuProcess=subprocess.Popen(['python',danmuApp.pathconfig.douyuHook_path,url],
                                          stdin=subprocess.PIPE,
                                          stderr=subprocess.PIPE,
                                          stdout=subprocess.PIPE,
                                          shell=True,
                                          universal_newlines=True,
                                          #encoding="utf-8"  # 加上这个参数之后stdout会把相应的bytes对象解码转换为str
                                          # stdin会把相应的str对象 编码为相应的bytes对象
                                          )
            while workingStruct[url]["processRun"]:
                danmuStr=douyuProcess.stdout.readline()
                if danmuStr:
                    #print(json.loads(danmuStr))
                    async_to_sync(self.channel_layer.group_send)(  # 分发给对应的处理函数处理 type 为consumer中的处理函数名字
                         self.groupName,
                         {
                             "type": "group_message",
                             "message": json.dumps(json.loads(danmuStr),ensure_ascii=False)
                         }
                    )
                # else:
                #     # err=douyuProcess.stderr.readline()
                #     # print(err.decode())
                #     time.sleep(1)
            douyuProcess.kill()
            print(workingStruct[self.currentUrl]["groupName"] + "  thread: "+threading.current_thread().getName()+" closed")
            workingStruct.pop(self.currentUrl)
            print("连接彻底关闭")

class DanmuConsumer2(WebsocketConsumer):
    def connect(self):
        #print(self.scope)
        self.currentUrl=""
        self.accept()
        print("连接已经建立")
    def disconnect(self, code):
        print("连接请求关闭")
        self.disconnecthandler()

    def receive(self, text_data=None, bytes_data=None):
        # print(text_data)
        #time.sleep(100)
        self.dataHandler(text_data)
    def disconnecthandler(self):
        self.process.terminate()
        print("关闭处理函数完毕")

    def dataHandler(self,data):
        json_data = json.loads(data)
        print(json_data)
        self.type = json_data['hooktype']
        self.currentUrl = json_data['url']
        self.process=subprocess.Popen(['python',danmuApp.pathconfig.douyuHook_path,self.currentUrl],
                                          stdin=subprocess.PIPE,
                                          stderr=subprocess.STDOUT,
                                          stdout=subprocess.PIPE,
                                          shell=True,
                                          universal_newlines=True,
                                          )
        while True:
            utf8code=self.process.stdout.readline()
            if utf8code:
                 #print(utf8code)
                 self.send(text_data=json.dumps(json.loads(utf8code),ensure_ascii=False))
            else:
                 print("暂时没有弹幕信息！")
                 time.sleep(1)
if __name__=='__main__':
    mystr="sfsdfsdfsdfh"
    mystr2=mystr
    mystr2.replace("h",'T')
    print(mystr)
    print(mystr2)
    pass





