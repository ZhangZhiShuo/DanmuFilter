workingStruct={}
