from django.shortcuts import render
from danmuApp.danmuHook import douyuDanmuHook,quanminDanmuHook,zhanqiDanmuHook,bilibiliDanmuHook,xiongmaoDanmuHook,xiongmaoxingxiuDanmuHook
from danmuApp.danmuHook.huyaDanmuHook import huyaDanmuHook
from django.http import HttpResponse
# Create your views here.
def danmu_url_handler(request):
    url=request.GET.get("url")
    typecode=int(request.GET.get("typecode"))
    if typecode == 0 or typecode == 1:
        danmuobj = douyuDanmuHook.DouyuDanmuHook()
        danmuobj.room_info_hook(url=url)
        return render(request,"resolution_page.html",context={
            "roomState":danmuobj.roomState,
            "url": danmuobj.url,
            "type":"douyu"
        })
    elif typecode == 7:
        pass
    elif typecode == 2:
        pass
    elif typecode == 3:
        pass
    elif typecode == 4:
        pass
    elif typecode == 5:
        pass
    elif typecode == 6:
        pass
def blankpage(request):
    return HttpResponse('')