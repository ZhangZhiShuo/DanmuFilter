from django.apps import AppConfig


class DanmuappConfig(AppConfig):
    name = 'danmuApp'
