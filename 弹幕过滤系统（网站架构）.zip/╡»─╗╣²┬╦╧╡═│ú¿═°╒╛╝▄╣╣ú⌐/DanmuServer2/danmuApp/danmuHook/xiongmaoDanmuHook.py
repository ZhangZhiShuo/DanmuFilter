import requests
import websocket
import time
import math
import json
import zlib
from threading import Thread
import re


'''

opcode 操作码，用于标识该帧负载的类型，如果收到了未知的操作码，则根据协议，需要断开WebSocket连接。操作码含义如下： 
0x00 连续帧，浏览器的WebSocket API一般不会收到该类型的操作码 
0x01 文本帧，最常用到的数据帧类别之一，表示该帧的负载是一段文本(UTF-8字符流) 
0x02 二进制帧，较常用到的数据帧类别之一，表示该帧的负载是二进制数据 
0x03-0x07 保留帧，留作未来非控制帧扩展使用 
0x08 关闭连接控制帧，表示要断开WebSocket连接，浏览器端调用close方法会发送0x08控制帧 
0x09 ping帧，用于检测端点是否可用，暂未发现浏览器可以通过何种方法发送该帧 
0x0A pong帧，用于回复ping帧，暂未发现浏览器可以发送此种类型的控制帧 
0x0B-0x0F 保留帧，留作未来控制帧扩展使用
'''
class xiongmaoDanmuHook():
    def __init__(self,url):
        self.url=url
        self.roomId=None
        self.__ws=None
        self.__danmuServer=None
        self.__data=None
        self.notDone=True
        #self.__xiongmaoCompile=re.compile(r'{"type":"1","time":(\d+),.*"nickName":"([\S+])",.*"rid":"(\d+)".*"content":"(\S+)"')
        self.__xiongmaoCompile = re.compile(
            r'{"type":"1","time":(\d+),.+?"nickName":"(.+?)",.+?"rid":"(\d+)".+?"content":"(.+?)"')
        self.xiongmaoDanmuJson={}
    def __keepalive(self):
        while self.notDone:
             time.sleep(30)
             heartbeat = bytes.fromhex("00060000")#心跳信息
             self.__ws.send(heartbeat, opcode=websocket.ABNF.OPCODE_BINARY)
    def runApp(self):
        self.initWebSocket()
    def closeApp(self):
        self.notDone=False
        self.__ws.close()
    def get_xiongmaoDanmuServerInfo(self):
      roomId_reg=re.search('https://www.panda.tv/(\d+)',self.url)
      if roomId_reg:
        self.roomId=roomId_reg.group(1)
        print(self.roomId)
        request_header={
         "Accept": "*/*",
         "Accept-Encoding":"gzip,deflate,sdch,br",
         "Accept-Language": "zh-CN, zh;q=0.8",
         "Cache-Control": "max-age = 0",
         "Connection":"keep-alive",
         "Host" :"riven.panda.tv",
         "Origin": "https://www.panda.tv",
         "Referer": "https://www.panda.tv/{0}".format(self.roomId),
         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.4882.400 QQBrowser/9.7.13059.400"
        }
        params={
            'roomid': self.roomId,
            'app':  1,
            'protocol': 'ws',
            '_caller': 'panda-pc_web',
            '_': math.floor(time.time())
        }
        req=requests.get(url="https://riven.panda.tv/chatroom/getinfo",params=params,headers=request_header,verify=False)
        #params 会转化为url 中的query string verify 表示不验证https协议的证书
        #print(req.text)
        self.__data=json.loads(req.text)["data"]
        self.__danmuServer=self.__data["chat_addr_list"][0]
        #print(self.__danmuServer)
    def initWebSocket(self):
        self.get_xiongmaoDanmuServerInfo()
        #websocket.enableTrace(True)
        danmu_server_url="wss://"+self.__danmuServer
        print(danmu_server_url)
        ws=websocket.WebSocketApp(danmu_server_url)
        ws.on_open=self._loginxiongmaoDanmubyWebSocket#打开之后 再注册心跳函数
        ws.on_message=self._receiveChatMsg
        self.__ws=ws
        self.__ws.run_forever(origin="https://www.panda.tv")
    def _loginxiongmaoDanmubyWebSocket(self,ws):
        loginmsg="u:{0}@{1}\nts:{2}\nsign:{3}\nauthtype:{4}\nplat:jssdk_pc_web\nversion:0.5.9\npdft:\nnetwork:unknown\ncompress:zlib".format(
            self.__data['rid'],
            self.__data['appid'],
            self.__data['ts'],
            self.__data['sign'],
            self.__data['authType']
        )
        loginHeader=int(6).to_bytes(length=2,byteorder='big')+int(2).to_bytes(length=2,byteorder='big')+len(loginmsg).to_bytes(length=2,byteorder='big')
        self.__ws.send(loginHeader+loginmsg.encode('utf-8'),opcode=websocket.ABNF.OPCODE_BINARY)
        heartbeats = Thread(target=self.__keepalive, name="Send-Heartbeats")
        heartbeats.start()
    def _receiveChatMsg(self,ws,message):
        #print(message)
        if len(message)<5:
            return
        op=int.from_bytes(message[2:4],byteorder='big')
        if op==3:
           usefulMsg=zlib.decompressobj().decompress(message[15:]).decode('utf-8','ignore')#解析块，可以没有尾，但必须有头 x\x9c 一个解析对象只能进行一次解析活动
           #print(usefulMsg)
           useful_segment=self.__xiongmaoCompile.search(usefulMsg)
           #print(useful_segment)
           if useful_segment:
               #print(useful_segment.group(0))
               self.xiongmaoDanmuJson["time"]=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(int(useful_segment.group(1))))
               self.xiongmaoDanmuJson["userName"]=useful_segment.group(2)
               self.xiongmaoDanmuJson["userId"]=useful_segment.group(3)
               self.xiongmaoDanmuJson["danmuContent"]=useful_segment.group(4)
               self.xiongmaoDanmuJson["roomId"]=self.roomId
               print(self.xiongmaoDanmuJson)
if __name__ == '__main__':

    bytesa=b'x\x9cT\x90=N\xc30\x1c\xc5\xe1*o\x8eZ\xc7v>\x9cCp\x05\xe4&v\t4u\x94\xba\x88\xaa\xca\x88\xd4\x81\x05\t\xa9 eadbCt\x80\xd3T\xa1\xc7@\xff \xbe\xbc\xd8~\xf6{\xbfg\x1f\xfd\x1b\xc7\xb35\xfc\xaa6\xc8 \x84D\x00_V\x06Y\x18q\xc9\x95\x8cX\x1a\xa0\xd0^#[\xc36\xae\xa2Y_j\xaf\x1bd8\xf3\xbe\xce\xc6\xe32\x1d\xd5EY\x8d\xa6\x8b1K\xac,X\x1cZk\xa2$\x95ElU\xac\x95\xd1y<1Q\xa2\xc4\xe8\xbc\x9e"\xc0\xbc\xcc/N4qpx{\xea\xdf\xbb\xfd\xeb\x0b\x024e\x81\x0c!c\x8as\x192\xb4\x01\xbc#\xe2\x9f\xfb\xfb\xddf\xbf\xdb\xf4\x0f\xdb\xfe\xfe\xb9\xdf\xdc\xfe\xb8D\xa8\x98\x92\x9c\xd1\x0b\\\xe3\xa8)hs5\x9c&B\xf1T\x08J\xcc\xdd\xdc\x9b\xb9\xa7\xd8\xdcU\x13GD\x90\xbc$qX\x0f\x96H\xe9B\xb2\x88i\xcby\xa8\xe2\xd4\xe6"Nd\xc2\xa9\xfeW\x95\x8f\xbb\xee\xd0u\xfd\xf6\xfa\xf0x\x83\x00\x0b\xbf\x9a\x99\xd3\xef\xbfd\x14\xb4\\\x98\xe6\x17\xd2\xb6\xed\'\x00\x00\x00\xff\xff'
    print(bytesa[2:])
    # print(type(bytes))

    decompressedobj=zlib.decompressobj();
    decompressed = decompressedobj.decompress(bytesa)
    #decompressed2 = decompressedobj.decompress(bytesa)
    # print(decompressedobj.unconsumed_tail)
    # print(decompressedobj.decompress(decompressedobj.unconsumed_tail))
    print(decompressed)
    #print(decompressed2)
    print(time.time())
    print(time.strftime('%Y-%m-%d %H:%M:%S'))
    a=xiongmaoDanmuHook("https://www.panda.tv/11010")
    a.runApp()
