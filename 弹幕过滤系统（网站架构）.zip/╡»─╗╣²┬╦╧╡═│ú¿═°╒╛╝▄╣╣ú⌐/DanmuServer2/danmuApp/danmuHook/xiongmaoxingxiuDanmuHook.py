import requests
import asyncio
import random
import struct
import time
import hashlib
import re
import socket
import json
class XiongmaoXingxiuDanmuHook(asyncio.Protocol):
    def __init__(self,url,loop):
        self.loop=loop
        self.url=url
        self.roomId=None
        self.compile=re.compile(r'{"from":.+?"type":"chat",.+?"plat":".+?"}')
        self.serverInfo={}
        self.loginInfo={}
        self.eachDanmuJson={}
        # "7773" + ("0000000000000000" + now.getTime().toString(16)).substr(-16) + ("000000000000" + int(Math.random() * 1000000000).toString(16)).substr(-12);
        self.guid="7773"+("0000000000000000"+hex(int(time.time()))[2:])[-16:]+("000000000000"+hex(int(random.random()*1000000000))[2:])[-12:]
    def connection_lost(self, exc):
        print("The connection  is closed", self.transport)
        print('Stop the event loop')
        print(exc)
        self.loop.stop()
    def connection_made(self, transport):
        self.transport=transport
        print("Connection made————", transport)
        self.transport.write(self.makeLoginMsg())
    def data_received(self, data):
        #print(data.decode('utf-8','ignore'))
        result=self.compile.search(data.decode('utf-8','ignore'))
        if result:
            usefuljson=json.loads(result.group(0))
            self.eachDanmuJson['nick']=usefuljson['from']['nick']
            self.eachDanmuJson['rid']=usefuljson['from']['rid']
            self.eachDanmuJson['role_name']=usefuljson['from']['role_name']
            self.eachDanmuJson['danmuContent']=usefuljson['data']['text']
            print(self.eachDanmuJson)
    def getSRInfo(self):
        """
        获取
        房间id
        弹幕服务器id
        与弹幕服务器关键的握手信息
        :return: 房间id和弹幕服务器id
        """
        search_result=re.search(r'https://xingyan.panda.tv/(\d+)',self.url)
        if search_result:
            self.roomId=search_result.group(1)
            getPayLoad={}
            getPayLoad["guid"]=self.guid
            getPayLoad["time"]=int(time.time())
            getPayLoad["cluster"]="v3"
            getPayLoad["plat"]="pc_web"
            getPayLoad["xid"]=self.roomId
            hmd5=hashlib.md5()
            hmd5.update(("uzY@H/C!N^G9K:EY" + getPayLoad["guid"] + getPayLoad["cluster"] + str(getPayLoad["time"])).encode())
            getPayLoad["sign"]=hmd5.hexdigest()
            #print(getPayLoad)
            res=requests.get(url="https://online.panda.tv/dispatch",params=getPayLoad,headers={
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
              }).json()
            print(res)
            self.serverInfo['ip']=socket.gethostbyname(res["addr"])
            self.serverInfo['port']=res['port']
            self.loginInfo['rnd']=res['rnd']
            self.loginInfo['id']=res['id']
            print(self.serverInfo,self.loginInfo)
    def toBytesList(self,str):
        i=0
        byteslist=[]
        substrlist=[]
        if len(str)&1==1:
            str='0'+str
        while i<len(str):
            substrlist.append(str[i:i+2])
            i+=2
        for i,val in enumerate(substrlist):
            byteslist.append(struct.pack('B',int(val,16)))
        return byteslist
    def makeLoginMsg(self):
        params={}
        '''
               var _loc2_:ByteArray = new ByteArray();
                _loc2_.writeBytes(this.toArray(gVars.guid),0,16);
                _loc2_.writeBytes(this.toArray(this.info.rnd),0,20);
                this.sendBinary(2147483649,_loc2_);
 public function sendBinary(param1:uint, param2:ByteArray) : *
      {
         var _loc3_:ByteArray = new ByteArray();
         _loc3_.writeByte(3);
         _loc3_.writeByte(0);
         _loc3_.writeByte(0);
         _loc3_.writeByte(0);
         _loc3_.writeDouble(Math.random());
         _loc3_.writeUnsignedInt(param1);
         _loc3_.writeUnsignedInt(0);
         _loc3_.writeUnsignedInt(param2.length);
         this.socket.writeBytes(_loc3_);
         this.socket.writeBytes(param2);
         trace("send: header:" + this.fromArray(_loc3_));
         trace("send: body:" + this.fromArray(param2));
         this.socket.flush();
         trace("sent");
      }
        '''
        loginBytes=bytearray()
        loginBody=bytearray()
        params["guid"]=self.toBytesList(self.guid)
        params["rnd"]=self.toBytesList(self.loginInfo['rnd'])
        loginBody+=b''.join(params['guid'])
        loginBody += b''.join(params['rnd'])
        paramslength=len(loginBody)
        loginheader=struct.pack('>BBBBdIII',3,0,0,0,random.random(),2147483649,0,paramslength)
        print(loginheader)
        print(loginBody)
        loginBytes=loginheader+loginBody
        #print(loginBytes)
        return bytes(loginBytes)

if __name__=='__main__':
    #print(hex(int(time.time()))[2:])
    #print(b'0'==b'\x30')#一个是ascii码，一个是16进制表示
    #print(int('30',16))
    loop=asyncio.get_event_loop()

    xingxiu=XiongmaoXingxiuDanmuHook("https://xingyan.panda.tv/1429793?channel=web_xy-cate_xingxiu-tj_allcate",loop)
    xingxiu.getSRInfo()
    coro=loop.create_connection(lambda :xingxiu,host=xingxiu.serverInfo['ip'],port=xingxiu.serverInfo['port'])#注册协程
    transport,protocol=loop.run_until_complete(coro)
    loop.run_forever()
    loop.close()
