import subprocess
import json
import time
import sys
import requests, re
sys.path.append("../../")
from danmuApp.pathconfig import huyajs_path
class HuyaDanmuHook():
    def __init__(self,huyaUrl):
        self.huya_prefix="https://www.huya.com/"
        self.roomId=huyaUrl.replace(self.huya_prefix,"")
        print(self.roomId)
        self.jsSubprocess=subprocess.Popen(['node',huyajs_path,self.roomId],
                                           stdin=subprocess.PIPE,
                                           stderr=subprocess.PIPE,
                                           stdout=subprocess.PIPE,
                                           shell=True,
                                           #encoding="utf-8"#加上这个参数之后stdout会把相应的bytes对象解码转换为str
                                           #stdin会把相应的str对象 编码为相应的bytes对象
                                           )
        self.huyaDanmuDict={}
    def readDamuLine(self):
        while True:
            jsonStr=self.jsSubprocess.stdout.readline()
            if jsonStr:
               print(jsonStr.decode('utf-8'))
            else:
                # errorstr=self.jsSubprocess.stderr.readline()
                # while errorstr:
                #      print(errorstr.decode('gbk'))
                #      errorstr = self.jsSubprocess.stderr.readline()
                time.sleep(1)
            #tempDict=json.loads(jsonStr)
if __name__=='__main__':
    # huyaDanmuProcess=HuyaDanmuHook("https://www.huya.com/xuanzi")
    # huyaDanmuProcess.readDamuLine()


    s = requests.Session()
    url = 'http://lab1.xseclab.com/xss2_0d557e6d2a4ac08b749b61473a075be1/index.php'
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, sdch, br",
        "Accept-Language": "zh-CN,zh;q=0.8",
        "Connection": "keep-alive",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest"
    }
    res = s.get(url,headers=headers)
    res.encoding='utf-8'
    html=res.text
    print(html)
    reg = r'([0-9].+)=<'
    pattern = re.compile(reg)
    match = pattern.search(html)
    print(match.group(0))
    print(match.group(1))
    payload = {'v': eval(match.group(1))}
    print (s.post(url, data=payload).content)


