const huya_danmu = require('./index')
const client = new huya_danmu(process.argv[2])

client.on('connect', () => {
    console.log(`已连接huya ${process.argv[2]}房间弹幕~`)
})

client.on('message', msg => {
    switch (msg.type) {
        case 'chat':
            msgStr=JSON.stringify(msg)
            //console.log(`{"userName":${msg.from.name},"userId":${msg.from.rid},"danmuText":${msg.content},"danmuId":${msg.id},"theTime":${msg.time}}`)
            console.log(msgStr)
            break
        case 'gift':
            //console.log(`[${msg.from.name}]->赠送${msg.count}个${msg.name}`)
            break
        case 'online':
            //console.log(`[当前人气]:${msg.count}`)
            break
    }
})

client.on('error', e => {
    console.log(e)
})

client.on('close', () => {
    console.log('close')
})

client.start()