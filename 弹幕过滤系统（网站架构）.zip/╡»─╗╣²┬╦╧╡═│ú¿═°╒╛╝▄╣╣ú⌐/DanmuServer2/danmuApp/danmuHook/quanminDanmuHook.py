import requests
import asyncio
from struct import unpack,pack
import requests
import time
import re
import functools
class QuanminDanmuClient(asyncio.Protocol):
    def __init__(self,loop,url):
        self.transport=None
        self.url=url
        self.roomInfo={}
        self.serverIp=None
        self.serverPort=9098
        self.loop=loop
        self.each_danmu={}
        self.compile=re.compile(
            r'"chat":{"json":.+,\\"text\\":\\"(.+?)\\",\\"time\\":(\d+),.+\\"user\\":{\\"id\\":(\d+),.+?,\\"nick\\":\\"(.+?)\\"')#.+,\"text"')
    def data_received(self, data):
        compile_result=self.compile.search(data.decode('utf-8','ignore'))
        if compile_result:
            self.each_danmu["danmuContent"]=compile_result.group(1).replace(r'\\','\\').replace(r'\\','\\').encode('utf-8').decode('unicode_escape')
            self.each_danmu['time']=time.strftime('%Y-%m-%d %H:%M:%S')
            self.each_danmu['userId']=compile_result.group(3)
            self.each_danmu['userName']=compile_result.group(4).replace(r'\\','\\').replace(r'\\','\\').encode('utf-8').decode('unicode_escape')
            print(self.each_danmu)
    def connection_made(self, transport):
        self.transport=transport
        print("Connection made————", transport)
        self.transport.write(self.createLoginMsg())


    def connection_lost(self, exc):
        print("The connection  is closed————", self.transport)
        print('Stop the event loop')
        self.loop.stop()
    def createLoginMsg(self):
        content = '{\n' \
               '   "os" : 135,\n' \
               '   "pid" : 10003,\n' \
               '   "rid" : "%s",\n' \
               '   "timestamp" : 78,\n' \
               '   "ver" : 147\n}' % (int(self.roomInfo['roomId']))
        data=pack('>i',len(content))+content.encode('utf-8')+b'\x0a'
        return data
    def get_serverip(self):
        headers = {
            "Accept": "text/html",
            "Accept-Encoding": "gzip, deflate, sdch, br",
            "Accept-Language": "zh-CN,zh;q=0.8",
            "Connection": "keep-alive",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
        }
        res=requests.get('http://www.quanmin.tv/site/route?time='
                + str(int(time.time())),headers=headers).content

        self.serverIp='.'.join([str(i^172) for i in unpack('>iiii',res[:16])])
        res=requests.get(self.url,headers=headers).text
        compile_result=re.search(r'{"uid":(\d+),.+"title":"(.+?)","nick":"(.+?)",',res)
        if compile_result:
            self.roomInfo["roomId"]=compile_result.group(1)
            self.roomInfo["roomTitle"]=compile_result.group(2)
            self.roomInfo["Nick"]=compile_result.group(3)
        print(self.roomInfo,self.serverIp)
def runQuanminHookApp():

    loop=asyncio.get_event_loop()
    quanminApp =QuanminDanmuClient(url="https://www.quanmin.tv/28092450",loop=loop)
    quanminApp.get_serverip()
    coro=loop.create_connection(lambda :quanminApp,host=quanminApp.serverIp,port=quanminApp.serverPort)
    transport,protocol=loop.run_until_complete(coro)
    #loop.call_later(delay=30, callback=functools.partial(ZhanqiDanmuHookClient.keepalive, transport=transport, loop=loop))
    loop.run_forever()
if __name__=='__main__':
    # list1=[1,2,4]
    # list2=[1,4,5]
    # print(list1+list2)
    #dir = r"\this\is\my\dos\dir""\\""sdfsdf"
    #print(dir)
    runQuanminHookApp()
   #string="\\\\\\\\u78a7\\\\\\\\u54e5\\\\\\\\u6210\\\\\\\\u540d"
   #print(list(string))
   #print(string.replace(r'\\','\\').replace(r'\\','\\').encode('utf-8'))
   #encode('unicode_escape')在unicode编码中添加转义字符
   #decode('unicode_escape')在unicode编码中去掉转义字符
   #print(string.replace(r'\\','\\').replace(r'\\','\\').encode('utf-8').decode('unicode_escape'))
   #print(list(string.replace(r'\\','\\').replace(r'\\','\\').replace(r'\\','\\')))
