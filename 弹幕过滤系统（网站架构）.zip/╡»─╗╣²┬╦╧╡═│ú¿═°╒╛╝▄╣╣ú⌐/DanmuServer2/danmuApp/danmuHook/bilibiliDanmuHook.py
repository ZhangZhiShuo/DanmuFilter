import websocket
import re
import requests
import json
import threading
import time
import ssl
class BilibiliDanmuClient():
    def __init__(self,url):

        self.url=url
        self.danmuServer='wss://broadcastlv.chat.bilibili.com:2245/sub'
        self.roomInfo={}
        self.danmuInfo={}
        self.__ws=None
    def getRoomInfo(self):
        id_search=re.search('https://live.bilibili.com/(\d+)',self.url)
        if id_search:
            id=id_search.group(1)
            request_header={
                "Host": "api.live.bilibili.com",
                "Connection":"keep-alive",
                "Cache-Control": "max-age = 0",
              "Accept": "application / json, text / plain, * / *",
              "Origin": "https: // live.bilibili.com",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.4882.400 QQBrowser/9.7.13059.400",
            "Referer": self.url,
            "Accept-Encoding": "gzip, deflate, sdch, br",
            "Accept-Language": "zh-CN, zh;q=0.8"
            }
            resjson=requests.get('https://api.live.bilibili.com/room/v1/Room/room_init',params={"id":id},headers=request_header ).json()
            #print(resjson)
            self.roomInfo['roomId']=resjson['data']['room_id']
            self.roomInfo['shortId']=resjson['data']['short_id']
            print(self.roomInfo)
    def initWebSocket(self):
        #websocket.enableTrace(True)
        self.__ws=websocket.WebSocketApp(url=self.danmuServer,header={
            "User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.104 Safari/537.36 Core/1.53.4882.400 QQBrowser/9.7.13059.400"
        })
        self.__ws.on_open=self.sendLoginMsg
        self.__ws.on_message=self.receiveMsg
        self.__ws.on_error=self.websocket_onerror
        self.__ws.run_forever(origin='https://live.bilibili.com',host='broadcastlv.chat.bilibili.com:2245',sslopt={"cert_reqs": ssl.CERT_NONE})
    def websocket_onerror(self,ws, error):
        print(error)
    def sendLoginMsg(self,ws):
        print("WebSocket to %s is ok"%self.danmuServer)
        self.getRoomInfo()
        content={
            "uid":0,
            "roomid":int(self.roomInfo['roomId']),
            "protover":1,
            "platform": "web",
        "clientver": "1.3.3",
        }
        header=bytes.fromhex("001000010000000700000001")
        loginMsg=header+json.dumps(content).encode('utf-8')
        self.__ws.send((len(loginMsg)+4).to_bytes(length=4,byteorder='big')+loginMsg)
        heartBeatThread=threading.Thread(target=self.heartBeat,name='bilibiliHeartBeat')
        heartBeatThread.start()
    def receiveMsg(self,ws,message):
        danmuList=re.findall(r'{"info":\[.+?\],"cmd":"DANMU_MSG"}',message.decode('utf-8','ignore'))
        for danmu in danmuList:
            #print(danmu)
            danmnjson=json.loads(danmu)
            self.danmuInfo['danmuContent']=danmnjson['info'][1]
            self.danmuInfo['userId']=danmnjson['info'][2][0]
            self.danmuInfo['userNick']=danmnjson['info'][2][1]
            print(self.danmuInfo)

    def heartBeat(self):
        while True:
            self.__ws.send(bytes.fromhex("0000001f0010000100000002000000015b6f626a656374204f626a6563745d"))
            time.sleep(30)
if __name__=='__main__':
    bi=BilibiliDanmuClient('https://live.bilibili.com/102?visit_id=76ax8pz4vws0')
    bi.initWebSocket()