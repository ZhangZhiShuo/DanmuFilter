import requests
import re
import json
import socket
import asyncio
import functools
import time
import sys
import os
#sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
sys.path.append(os.path.join( os.path.dirname(__file__), '../..'))
import danmuApp.pathconfig as pathconfig
from danmuApp.danmuFilter.main_filter import DanmuFilter
from danmuApp.danmuFilter.percentFilterMethod.PercentFilterMethod import PercentMethodFilter
def client_packaging_msg(msg):
    """
               douyu 格式
               byte0  byte1  byte2   byte3
                        len
                        len
                    code    加密（0）  保留（0）
               数据部分(结尾必须为‘\0’)
                 code：
                 689  客户端发送给弹幕服务器的文本格式数据
                 690  弹幕服务器发送给客户端的文本格式数据。
    """
    msg_len = len(msg) + 8
    code = 689
    encryption = 0
    left = 0
    all_the_msg = msg_len.to_bytes(4, byteorder='little') + \
                  msg_len.to_bytes(4, byteorder='little') + \
                  code.to_bytes(2, byteorder='little') + \
                  encryption.to_bytes(1,byteorder='little') + \
                  left.to_bytes(1, byteorder='little') +\
                  bytes(msg, 'utf-8')
    return all_the_msg
class DouyuDanmuHook(asyncio.Protocol):
       def __init__(self):
           self.transport=None
           self.loop=None
           self.douyu_prefix="https://www.douyu.com/"
           self.douyu_special_prefix="https://www.douyu.com/t/"
           self.roomState={ }
           self.each_danmu_json={}
           self.specialRoomId=None
           self.socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
           self.danmu_format = re.compile('chatmsg/rid@=(\d+?)/.*uid@=(\d+?)/.*nn@=(.+?)/.*txt@=(.+?)/.*cid@=(\S+?)/ic@=.*level@=\d{1,3}')
           # group(1) 为roomId,group(2) 为userId,group(3)为userName ，group(4) 为 danmu_txt ,group(5) 为danmuId
       '''
                               参数一：地址簇

                       在这个参数中包含以下几个参数：

                       socket.AF_INET  表示IPV4(默认)

                       socket.AF_INET6 表示IPV6

                       socket.AF_UNIX   只能用于单一的Unix系统进程间的通信

                       参数二：类型

                       socket.SOCK_STREAM  流式socket for TCP（默认）

                       socket.SOCK_DGRAM   数据格式socket,for UDP

                       socket.SOCK_RAW     原始套接字，普通的套接字无法处理ICMP,IGMP等网络报文，可以通过IP_HDRINCL套接字选项由用户构造IP头

                       socket.SOCK_RDM      是一种可靠的UDP形式，即保证交付数据报但不保证顺序，SOCK_RDM用来提供对原始协议的低级访问，在需要执行某些特殊操作时使用，如发送ICMP报文，SOCK_RAM通常仅限于高级用户或管理员运行的程序使用

                       socket.SOCK_SEQPACKET  可靠的连续数据包服务

                       参数三：协议

                       默认与特定地址家族相关的协议，如果是0 则系统就会根据地址格式和套接类别，自动选择一个合适的协议
                       '''

       def setFilter(self,filter):
           self.filter=filter
       def setFilter2(self,filter):
           self.filter2=filter
       def setLoop(self,loop):
           self.loop=loop
       def setGroupId(self,groupid):
           self.groupId=groupid
       def setChannelLayer(self,channelLayer):
           self.channelLayer=channelLayer
       def room_info_hook(self,url):
          self.url = url
          if self.douyu_special_prefix in self.url:
              headers = {
                  "Accept": "*/*",
                  "Accept-Encoding": "gzip, deflate, sdch, br",
                  "Accept-Language": "zh-CN,zh;q=0.8",
                  "Connection": "keep-alive",
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36",
                  "X-Requested-With": "XMLHttpRequest"
              }
              res=requests.get(self.url,headers=headers)
              #print(res.encoding)
              res=res.text
              result=re.search(r'<div data-component-id=.+?data-onlineid=.*?(\d+)',res)
              self.specialRoomId=result.group(1)
              # print(self.specialRoomId)
              res=requests.get('https://www.douyu.com/ztCache/WebM/room/%s'%self.specialRoomId,headers=headers).json()
              #print(json.loads(res["$ROOM"]))
              roomInfoJson=json.loads(res["$ROOM"])
              self.roomState["id"] = roomInfoJson['room_id']
              self.roomState["roomName"] = roomInfoJson["room_name"]#.replace(r"\\",'\\').encode('utf-8').decode('unicode_escape')
              self.roomState["ownerName"] = roomInfoJson["owner_name"]#.replace(r"\\",'\\').encode('utf-8').decode('unicode_escape')
              self.roomState["ownerUid"] = roomInfoJson["owner_uid"]
              #print(self.roomState)
              return True
          else:
            if self.douyu_prefix not in self.url:
               return False
            else:
                  session = requests.session()
                  session.headers = {
                  "Accept": "*/*",
                  "Accept-Encoding": "gzip, deflate, sdch, br",
                  "Accept-Language": "zh-CN,zh;q=0.8",
                  "Connection": "keep-alive",
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
                  }
                  res=session.get(self.url)
                  #print(res.encoding)
                  douyu_roomHtml = res.text
                  #print(douyu_roomHtml)
                  roomStateJson=json.loads(re.search('var\s\$ROOM\s=\s({.*});',douyu_roomHtml).group(1))
                  #print(roomStateJson)
                  self.roomState["id"]=roomStateJson["room_id"]
                  self.roomState["roomName"]=roomStateJson["room_name"]
                  self.roomState["ownerName"]=roomStateJson["owner_name"]
                  self.roomState["ownerUid"]=roomStateJson['owner_uid']
                  return True
       def doLogin(self):
           roomId = self.roomState["id"]
           login_msg = "type@=loginreq/roomid@={0}/\0".format(roomId)
           all_the_msg = client_packaging_msg(login_msg)
           self.transport.write(all_the_msg)
       def doJoinGroup(self):
           roomId = self.roomState["id"]
           joinGroup_msg = "type@=joingroup/rid@={0}/gid@=-9999/\0".format(roomId)
           all_the_msg = client_packaging_msg(joinGroup_msg)
           self.transport.write(all_the_msg)
       def connection_made(self,transport):
           self.transport=transport
           self.doLogin()
           self.doJoinGroup()
       def data_received(self, data):
           each_danmu=data.decode('utf-8','ignore')
           # print(each_danmu)
           useful_segment = self.danmu_format.search(each_danmu)
           if useful_segment is not None:
               self.each_danmu_json["roomId"] = useful_segment.group(1)
               self.each_danmu_json["userId"] = useful_segment.group(2)
               self.each_danmu_json["userName"] = useful_segment.group(3)
               self.each_danmu_json["danmuContent"] = useful_segment.group(4)
               self.each_danmu_json["danmuId"] = useful_segment.group(5)
               self.each_danmu_json["time"]=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
               self.each_danmu_json["path"]=self.filter.filter(self.each_danmu_json["danmuContent"])
               if self.each_danmu_json["path"]:
                   self.each_danmu_json["error"]=1
               else:
                  if self.filter2.filter(self.each_danmu_json["danmuContent"]):
                       self.each_danmu_json["error"]= 1
                  else:
                       self.each_danmu_json["error"] = 0
               print(json.dumps(self.each_danmu_json))
               sys.stdout.flush()
               # print(json.dumps(obj=self.each_danmu_json, ensure_ascii=False))
               # with open(file="room" + self.each_danmu_json["roomId"] + "Danmu.txt", mode="a", encoding="utf8") as f:
               #     f.write(json.dumps(obj=self.each_danmu_json, ensure_ascii=False) +'\n')
           #print('Data received:{!r}\n'.format(data.decode('utf-8','ignore')))
       def connection_lost(self, exc):
           print("The connection to"+self.url+" is closed")
           print('Stop the event loop of'+self.url)
           self.loop.stop()
       @classmethod
       def keeplive(cls,transport,loop):
           keeplive_msg = "type@=mrkl/\0"
           all_the_msg = client_packaging_msg(keeplive_msg)
           transport.write(all_the_msg)
           loop.call_later(delay=30,callback=functools.partial(DouyuDanmuHook.keeplive,transport=transport,loop=loop))
if __name__=='__main__':
      dirs = os.path.join(os.path.dirname(__file__), '../..')
      #print(sys.path)
      loop=asyncio.get_event_loop()
      d=DouyuDanmuHook()
      filter = DanmuFilter()
      filter2=PercentMethodFilter()
      filter.loads(pathconfig.dirty_txt_path)
      filter2.loads(pathconfig.dirty_code_path)
      d.setFilter(filter)
      d.setFilter2(filter2)
      d.room_info_hook(url=sys.argv[1])
      #d.room_info_hook(url="https://www.douyu.com/138243?ADTAG=zd-liveplug")
      d.setLoop(loop)
      #d = DouyuDanmuHook(url=None,specialRoomId=6, loop=loop)
      coro=loop.create_connection(lambda :d,host=socket.gethostbyname("openbarrage.douyutv.com"),port=8601)
      transport,protocol=loop.run_until_complete(coro)
      loop.call_later(delay=30,callback=functools.partial(DouyuDanmuHook.keeplive,transport=transport,loop=loop))
      loop.run_forever()
      loop.close()








