import json
import re
import requests
import asyncio
import base64
import time
import functools
class ZhanqiDanmuHookClient(asyncio.Protocol):
    def __init__(self,url,loop):
        self.__url=url
        self.__roomId=None
        self.serverIp=None
        self.serverPort=None
        self.__roomInfo={}
        self.transport=None
        self.loop=loop
        self.compile=re.compile('"fromname":"(.+?)","content":"(.+?)","cmdid":"chatmessage"}')
        self.each_danmu={}
    def getRoomInfo(self):
        request_headers={
            "Accept": "text/html",
            "Accept-Encoding": "gzip, deflate, sdch, br",
            "Accept-Language": "zh-CN,zh;q=0.8",
            "Connection": "keep-alive",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
        }
        res=requests.get(self.__url,headers=request_headers)
        raw_search=re.search('oRoom = (.*);[\s\S]*?window.',res.text)
        if not raw_search:raw_search=re.search('aVideos = (.*);[\s\S]*?oPageConfig.', res.text)
        if raw_search:
           serverInfo=json.loads(raw_search.group(1))
           if isinstance(serverInfo,list):serverInfo_json=serverInfo[0]
           else:serverInfo_json=serverInfo
           self.__roomId=serverInfo_json['id']
           serverAddress=json.loads(base64.b64decode(serverInfo_json['flashvars']['Servers']).decode('utf-8'))['list'][0]
           self.serverIp=serverAddress['ip']
           self.serverPort=serverAddress['port']
           res=requests.get('%s/api/public/room.viewer' % 'https://www.zhanqi.tv',params={
               'uid':serverInfo_json['uid'],
               '_t':int(time.time())/60,
           },headers=request_headers)
           self.__roomInfo=res.json()
           print(self.__roomInfo)
           print(self.serverIp+":"+str(self.serverPort))
    def __genLoginMsg(self):
        content=json.dumps({
            'nickname': '',
            'roomid': int(self.__roomId),
            'gid': self.__roomInfo['data']['gid'],
            'sid': self.__roomInfo['data']['sid'],
            'ssid':self.__roomInfo['data']['sid'],
            'timestamp': self.__roomInfo['data']['timestamp'],
            'cmdid': 'loginreq',
            'develop_date': '2015-06-07',
            'fhost': 'zhanqi.tool',
            'fx': 0,
            't': 0,
            'thirdacount': '',
            'uid': 0,
            'ver': 2,
            'vod': 0,
        })
        header=b'\xbb\xcc' + b'\x00'*4+len(content).to_bytes(length=4,byteorder='little')+b'\x10\x27'
        return header+content.encode('utf-8')
    def connection_made(self, transport):
        self.transport=transport
        print("Connection made————",transport)
        self.transport.write(self.__genLoginMsg())
    def connection_lost(self, exc):
        print("The connection  is closed————", self.transport)
        print('Stop the event loop')
        self.loop.stop()
    def data_received(self, data):
        compile_obj=self.compile.search(data.decode('utf-8','ignore'))
        if compile_obj:
            self.each_danmu["userName"]=compile_obj.group(1)
            self.each_danmu["danmuContent"]=compile_obj.group(2)
            self.each_danmu["time"]=time.strftime('%Y-%m-%d %H:%M:%S')
            print(self.each_danmu)
    @classmethod
    def keepalive(cls,transport,loop):
        transport.write(b'\xbb\xcc' + b'\x00'*8 + b'\x59\x27')
        loop.call_later(delay=30, callback=functools.partial(cls.keepalive, transport=transport, loop=loop))

def runZhanqiHookApp():

    loop=asyncio.get_event_loop()
    zhanqiApp = ZhanqiDanmuHookClient("https://www.zhanqi.tv/9527",loop=loop)
    zhanqiApp.getRoomInfo()
    coro=loop.create_connection(lambda :zhanqiApp,host=zhanqiApp.serverIp,port=zhanqiApp.serverPort)
    transport,protocol=loop.run_until_complete(coro)
    loop.call_later(delay=30, callback=functools.partial(ZhanqiDanmuHookClient.keepalive, transport=transport, loop=loop))
    loop.run_forever()
if __name__=='__main__':
    runZhanqiHookApp()






