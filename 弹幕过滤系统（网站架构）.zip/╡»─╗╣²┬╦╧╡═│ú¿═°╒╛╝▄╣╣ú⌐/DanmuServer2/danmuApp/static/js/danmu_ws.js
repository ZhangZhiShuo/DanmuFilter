class MyDanmuProtocol
{
    constructor(){
        this.onopenData={
            url:document.getElementById("url").getAttribute("data-type"),
            hooktype:document.getElementById("hooktype").getAttribute("data-type")
        }
        this.total_span=document.querySelector(".danmu-calculate-component>p .totality")
        this.total_count=0
        this.dirty_span=document.querySelector(".danmu-calculate-component>p .dirty-count")
        this.dirty_count=0
        this.calculate_percent=0
        this.calulate_span=document.querySelector(".danmu-calculate-component>p .calculate-span")
        this.handle_time=document.querySelector(".danmu-calculate-component>p .handle-time")
    }
    initWebSocket(initData)
    {
        self=this
        self.startTime=Date.now();
        self.websocket=new WebSocket("ws://"+window.location.host+"/danmu_resolution/")
        self.websocket.binaryType="arraybuffer"
        self.websocket.onopen=function (ev) {
            //console.log(ev)
            //console.log(initData)
            console.log("Websocket to the danmu server is opening")
            this.send(JSON.stringify(self.onopenData))
            console.log("Send data:  "+JSON.stringify(self.onopenData)+"to DanmuServer")

        }
        self.websocket.onmessage=function (ev) {

                let danmu = JSON.parse(ev.data)
                self.total_count++
                console.log(danmu)
                if (danmu.error) {
                    self.dirty_count++
                    window.$UIChangeFactory.insertliforul(
                        {
                            userName: danmu.userName,
                            danmuContent: danmu.danmuContent,
                            time: danmu.time
                        },
                        window.$DirtyDanmuContainer)
                }
                else {
                    window.$UIChangeFactory.insertliforul(
                        {
                            userName: danmu.userName,
                            danmuContent: danmu.danmuContent,
                            time: danmu.time
                        },
                        window.$GoodDanmuContainer)
                }
                self.calculate_percent = (100 * self.dirty_count / self.total_count).toString().slice(0, 4)
                self.total_span.innerHTML = self.total_count
                self.dirty_span.innerHTML = self.dirty_count
                self.handle_time.innerHTML=parseInt((Date.now()-self.startTime)/1000)+"秒"
                self.calulate_span.innerHTML = self.calculate_percent + "%"
        }

        self.websocket.onerror=function (ev) {
            console.log(ev)
        }
        self.websocket.onclose=function (ev) {
            console.log(ev)
        }
    }

}
var mywebsocket
window.onload=function () {
    setTimeout(function(){
        mywebsocket=new MyDanmuProtocol()
        mywebsocket.initWebSocket()
    },3000)
}

window.onbeforeunload=function () {
    mywebsocket.websocket.close()
}