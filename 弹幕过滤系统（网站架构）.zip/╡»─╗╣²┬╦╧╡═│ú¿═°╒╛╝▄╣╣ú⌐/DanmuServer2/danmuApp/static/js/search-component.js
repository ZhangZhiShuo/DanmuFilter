
class MyInputEvent {
    constructor(inputId,hiddenId)
    {
        var self=this;
        self.validateRules= {
                rules:[/https:\/\/www.douyu.com\/.+/,
                    /https:\/\/www.douyu.com\/t\/.+/,
                    /https:\/\/xingyan.panda.tv\/.+/,
                    /https:\/\/www.panda.tv\/.+/,
                /https:\/\/www.huya.com\/.+/,
                /https:\/\/www.zhanqi.tv\/.+/,
                /https:\/\/www.quanmin.tv\/.+/,
                /https:\/\/live.bilibili.com\/.+/],
                errormsg:"请复制正确的url（将要爬取的直播间的浏览器地址栏中的内容全部复制即可，后台会进行智能处理）",
                correctmsg:(currenturl)=>"url前端输入检测正确!您将要爬取的url为:&nbsp;&nbsp;"+currenturl

        }

        self.inputElement=document.getElementById(inputId);
        self.inputLabel=document.querySelector("#"+inputId+"+label")
        self.hiddenInput=document.getElementById(hiddenId)
        self.searchButton=document.querySelector(".search-container .search-button")
        self.searchButton_a=document.querySelectorAll(".search-container .search-button a")
        self.msgp=document.createElement('p')
        self.inputLabel.parentElement.appendChild(self.msgp)
        // self.inputElement.onfocus=function (e) {
        //     if(e) {
        //         e.preventDefault()
        //     }
        //     self.inputLabel.classList.add('active')
        // }
        self.inputElement.onblur=function (e) {
            if(e)
            {
                e.preventDefault()
            }
            if(!this.value)
            {
                self.inputLabel.className="";
                self.inputElement.className="";
                self.msgp.className="";
                self.msgp.textContent="";
                //self.inputLabel.classList.remove('active')
            }

        }
    }
    initValidate()
    {
        var self=this
        self.inputElement.oninput=function (e) {
            if(e)
            {
                e.preventDefault()
            }
            let i,result;
            for(i=0;i<self.validateRules.rules.length;i++) {
                result=this.value.match(self.validateRules.rules[i])
                //console.log(self.validateRules.rules[i])
                //console.log(result)
                if(result)
                {
                    self.typecode=i
                    self.msgp.innerHTML=self.validateRules.correctmsg(this.value);
                    self.msgp.className="correctp";
                    self.inputElement.className="correct"
                    self.inputLabel.classList.remove("incorrect")
                    self.inputLabel.classList.add("correct")
                    self.searchButton.classList.remove("disabled")
                    for(let j=0;j<self.searchButton_a.length;j++)
                    {
                        self.searchButton_a[j].setAttribute('href','/danmu_resolution?'+
                            'url='+ encodeURIComponent(self.inputElement.value)+
                        '&typecode='+encodeURIComponent(self.typecode))
                        self.searchButton_a[j].setAttribute('target','_blank')
                    }
                    break;
                }
            }
            //console.log(i)
            if(i==self.validateRules.rules.length)
            {
                let j;
                for(j=0;j<self.searchButton.classList.length;j++)
                {
                    if(self.searchButton.classList[j]=="disabled")
                    {
                        break;
                    }
                }

                if(j==self.searchButton.classList.length)
                {
                    self.searchButton.classList.add('disabled')
                }
                self.msgp.textContent=self.validateRules.errormsg;
                self.msgp.className="errorp";
                self.inputElement.className="incorrect"
                self.inputLabel.classList.remove("correct")
                self.inputLabel.classList.add("incorrect")
            }
        }
    }

}
var myinputevent=new MyInputEvent("url-input")
myinputevent.initValidate()
//export default MyInputEvent