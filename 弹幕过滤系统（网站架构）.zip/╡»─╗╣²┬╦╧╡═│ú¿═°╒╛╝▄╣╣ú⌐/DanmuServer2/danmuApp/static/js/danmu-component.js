;(function(global_win){
"use strict";
var self
var MyUiChange=function(){
    self=this
    this.countimg=1;
};
MyUiChange.prototype.insertliforul=function(data,danmu_container)
{
    if(!window.$SIGN) {
        danmu_container.scrollTop = danmu_container.scrollHeight - danmu_container.clientHeight
    }
    let ul_element=danmu_container.querySelector(".danmu-content .danmu-ul")
    let newli=document.createElement('li');
    newli.classList.add("eachdanmu");
    let newp=document.createElement("p");
    let newicon=document.createElement('img');
    newicon.classList.add("icon");
    newicon.setAttribute("src","../static/imgs/头像"+this.countimg+".png")
    newp.appendChild(newicon)
    newp.appendChild(self.createSpan(data.userName+":","color:#FF6600"))
    newp.appendChild(self.createSpan(data.danmuContent,""))
    newp.appendChild(self.createSpan("("+data.time+")","color:#6699FF"))
    newli.appendChild(newp);
    //console.log(ul_element.childElementCount)
    if(ul_element.childElementCount>=50)
    {
        ul_element.removeChild(ul_element.children[0])
    }
   ul_element.appendChild(newli);
   self.countimg++;
   if(self.countimg>4)
   {
       self.countimg=1;
   }
}

MyUiChange.prototype.createSpan=function(text,styleStr)
{
let newspan=document.createElement('span')
newspan.style=styleStr
newspan.innerHTML=text+"&nbsp;"
return newspan
}

global_win.MyUiChange=MyUiChange;
})(this)
    //console.log(window.location)
window.$SIGN=false
window.$GoodDanmuContainer=document.querySelector(".good-danmu-component .danmu-container ")
window.$GoodDanmuContainer.onmouseon=function(){
window.$SIGN=true
}
window.$GoodDanmuContainer.onmouseover=function(){
window.$SIGN=true
}
window.$GoodDanmuContainer.onmouseleave=function(){
window.$SIGN=false
}
window.$DirtyDanmuContainer=document.querySelector(".dirty-danmu-component .danmu-container ")
window.$UIChangeFactory=new MyUiChange()
// ul_elements=document.querySelectorAll(".danmu-container .danmu-content .danmu-ul");
// for(let i=0;i<ul_elements.length;i++)
// {   let ul_element=ul_elements[i]
//     let myuichange=new MyUiChange();
//     setInterval(function(){
//        myuichange.insertliforul({userName:"用户名",danmuContent:"sdfsdfsfds",time:"sfsfsdfsdf"},ul_element)
// },500)
// }
// setInterval(function(){
//         window.$UIChangeFactory.insertliforul({userName:"用户名",danmuContent:"sdfsdfsfds",time:"sfsfsdfsdf"},window.$GoodDanmuul)
//  },500)
