class Check(object):
    def __init__(selfs):
        pass
    def add_word(self,text):
        pass
    def get_bad_word(self,text,offset=0):
        pass
    def replace_bad_word(self,text,offset=0,mark='*'):
        pass