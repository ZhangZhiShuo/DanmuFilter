class ACTreeNode():
    def __init__(self,char):
        self.value=char
        self.children={}
        self.fail_pointer=None
        self.tail=None
    def get_value(self):
        return self.value
    def get_child(self,key):
        if self.children.__contains__(key):
            return self.children.get(key)
        else:
            return None
    def set_tail(self,tail):
        self.tail=tail
    def add_child(self,ch):
        if self.get_child(ch):
            return self.get_child(ch)
        else:
            newNode=ACTreeNode(ch)
            self.children[ch]=newNode
            return newNode

class ACTree():
    def __init__(self):
        self.root=ACTreeNode('')
        self.count=0
    def add_one_strmode(self,line):
          p=self.root
          for i in line:
             p=p.add_child(i)
          self.count+=1
          p.set_tail(self.count)
    def setFailPointer(self):
        queueList = [self.root]
        while queueList:
           temp=queueList.pop(0)
           for child_key in temp.children:
               if temp==self.root:
                   temp.children[child_key].fail_pointer=self.root
               else:
                   p=temp.fail_pointer#父节点的回溯结点
                   while p:
                       if child_key in p.children:
                           temp.children[child_key].fail_pointer=p.children[child_key]
                           break
                       p=p.fail_pointer#继续回溯，直到fail指针为空
                   if not p:#如果发现p为空，则将此结点的fail指针定为self.root
                       temp.children[child_key].fail_pointer=self.root
               queueList.append(temp.children[child_key])#向带处理列表中插入待处理项的父节点
    def runkmp(self,mystr):
        p = self.root
        matchCount={}
        for i in mystr:
            while i not in p.children and p is not self.root:
                p=p.fail_pointer
            if i in p.children:
                p=p.children[i]
            else:
                p=self.root#没查询到，下一个字符继续从根节点开始查询
                continue
            temp=p
            while temp is not self.root:
                if temp.tail:
                    if temp.tail in  matchCount:
                        matchCount[temp.tail]+=1
                    else:
                        matchCount[temp.tail]=1
                temp=temp.fail_pointer
        return matchCount










