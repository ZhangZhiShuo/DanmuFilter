from danmuApp.pathconfig import dirty_code_path
from danmuApp.danmuFilter.filter_prepare import FilterPrepare
class PercentMethodFilter():
    def __init__(self):
        self.filterSet=set()
        self.Prepare=FilterPrepare()
    def loads(self,file):
        with open(file=file,mode='r',encoding='utf-8') as f:
            str=f.read().replace('\n','')
            self.filterSet.update(str)
    def filter(self,text):
        text=self.Prepare.filterPrepare(text)
        count=0
        numcount=0
        setcache=set()
        numcache=set()
        numcache.update("0123456789一二三四五六七八九零①②〇Oo③④⑤⑥⑦⑧⑨ｏ１２３４５６７８９㈠㈡㈢㈣㈤㈥㈦㈧㈨⒈⒉⒊⒋⒍⒌⒎⒏⒐⑴⑵⑶⑸⑹⑺⑻⑼")
        setcache.update(self.filterSet)
        for code in text:
            if code in setcache:
                count+=1
                setcache.discard(code)
            if code in numcache:
                numcount+=1
                numcache.discard(code)
            if  numcount>=5 and count>=1:
                return True
            elif count>=3:
                return True
        return False
if __name__=="__main__":
    str='\u2460'
    print("①")
    myset=set()
    myset.update("ssfsfsfsdf")
    print(myset)
    p=PercentMethodFilter()
    p.loads(dirty_code_path)
    print(p.filterSet)
    setcache=set()
    setcache.update(p.filterSet)
    print(setcache)
    setcache.clear()
    print(p.filterSet)
    print(p.filter("这个是啥操作？"))