from danmuApp.danmuFilter.langconv import *
import re
class FilterPrepare(object):
    def __init__(self):
        pass
    def fj_transform(self,text):
        text= Converter('zh-hans').convert(text)#由简体到繁体
        #'zh-hant'由繁体到简体
        return text
    def easy_filter(self,text):
        text=re.sub(r'[!"#$%&\\\'()*,\-./:;<=>?@，。★、…【】《》？“”‘’！[\]^_`{|}~\s]+',"",text)
        #re.sub(r'[[\]]',"",text)
        #[]正则表达式中括号中不需要转义
        #如果没有[] 且没有r 则 匹配\需要 \\\\--->(python 转义)\\---->(正则转义)\  r的作用是取消python转义只用正则转义就行了
        #r \后边一定要有匹配的字符才会消除python转义字符的转义效果，所以最后一个不能是以\结尾
        #print(r'[’!"#$%&\'()*+,-./:;<=>?@，。?★、…【】《》？“”‘’！[\]^_`{|}~\s]+')
        return text
    def lower_transform(self,text):
        return text.lower()
    def filterPrepare(self,text):
        text = self.easy_filter(text)
        text=self.fj_transform(text)
        text=self.lower_transform(text)
        text = text.replace('+', '加')
        text = text.replace('脫','脱')
        text = text.replace('╅', '加')
        text = text.replace('ĉ', 'c')
        text = text.replace('Ǒ', 'o')
        text = text.replace('Ṏ', 'o')
        text = text.replace('M', 'm')
        text = text.replace('Ｍ', 'm')
        text=text.replace('Ḇ','b')
        text=text.replace('Ⓑ','b')
        return text

        '''
        sub(pattern, repl, string, count=0, flags=0) 
        pattern为表示正则中的模式字符串， 
repl为replacement，被替换的内容，repl可以是字符串，也可以是函数。 
string为正则表达式匹配的内容。 
count：由于正则表达式匹配到的结果是多个，使用count来限定替换的个数（顺序为从左向右），默认值为0，替换所有的匹配到的结果。 
flags是匹配模式，可以使用按位或’|’表示同时生效，也可以在正则表达式字符串中指定.
        1).re.I(re.IGNORECASE): 忽略大小写 
2).re.M(MULTILINE): 多行模式，改变’^’和’$’的行为 
3).re.S(DOTALL): 点任意匹配模式，改变’.’的行为 
4).re.L(LOCALE): 使预定字符类 \w \W \b \B \s \S 取决于当前区域设定 
5).re.U(UNICODE): 使预定字符类 \w \W \b \B \s \S \d \D 取决于unicode定义的字符属性 
6).re.X(VERBOSE): 详细模式。这个模式下正则表达式可以是多行，忽略空白字符，并可以加入注释
        '''
if __name__=='__main__':
    filterPrepare=FilterPrepare()
    text=filterPrepare.easy_filter("╅加騷女qq微信   ṎＭ習近平++? ?[]( )!!：12         4041200")
    text=filterPrepare.fj_transform(text)
    print(text)