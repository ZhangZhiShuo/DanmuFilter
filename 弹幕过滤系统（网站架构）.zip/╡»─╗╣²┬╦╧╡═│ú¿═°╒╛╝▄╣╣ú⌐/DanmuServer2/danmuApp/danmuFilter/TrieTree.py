from danmuApp.danmuFilter.Check import Check
import logging
class TrieNode(object):
    def __init__(self,value=None):
        self.__end=False
        self.__child={}
        self.__value=value
    def is_end(self):
        return self.__end
    def set_end(self,end):
        self.__end=end
    def get_child(self,ch):
        if self.__child.__contains__(ch):#检查是否包含key值 替换2.x中的has_key()
            return self.__child.get(ch)#返回对应的值 是一个Node对象
        else:
            return None
    def add(self,ch):
        if self.__child.__contains__(ch):#如果有子节点，返回子节点
            return self.__child.get(ch)
        else:
            newNode=TrieNode(ch)
            self.__child[ch]=newNode#如果没有，新建一个子结点，并返回这个子节点
            return newNode
    def get_value(self):
        return self.__value

class TrieCheck(Check):
    def __init__(self):
        self.__root=TrieNode('')
        self.logger=logging.getLogger('TrieCheck')
    def add_word(self,text):
        node = self.__root
        for i in text:
            node=node.add(i)
        node.set_end(True)
    def get_bad_word(self,text,offset=0):
        if not isinstance(text,str) or offset>=len(text):
            self.logger.info("弹幕经过过滤之后无字符了！")
            return False
        else:
            i=offset
            text=text[offset:]
            path=[]
            bad_words={}
            while i<=len(text)-1:
                node=self.__root#每次从根节点开始查询
                ch=text[i]
                node=node.get_child(ch)
                while True:
                  if node is not None:
                    bad_words[i]=node.get_value()
                    if i+1==len(text):#到最后了
                        if node.is_end():
                            path.append(bad_words)
                        return path
                    if node.is_end():#查询到末尾结点，部分脏字已经检查出， 需要从root 重新检测
                        path.append(bad_words)
                        i+=1
                        bad_words={}
                        break
                    i+=1
                    ch=text[i]
                    node=node.get_child(ch)
                  else:
                    i+=1
                    break
            return path
    def replace_bad_word(self,text,offset=0,mark='*'):
        if not isinstance(text,str) or offset>=len(text):
            self.logger.error("Please input str type or offset is too big")
            return False
        else:
            i=offset
            text=list(text[offset:])
            bad_words=""
            while i<=len(text)-1:
                node=self.__root#每次从根节点开始查询
                ch=text[i]
                node=node.get_child(ch)
                start=i
                while True:
                  if node is not None:
                    if i+1==len(text):
                        return text
                    if node.is_end():
                        for index in range(start,i+1):
                            text[index]=mark
                        i+=1
                        break
                    i+=1
                    ch=text[i]
                    node=node.get_child(ch)
                  else:
                    i+=1
                    break
            return "".join(text)#list合并成str
        pass
if __name__=='__main__':
    trieCheck=TrieCheck()
    print(type("saonv"))
    trieCheck.add_word("骚女")
    trieCheck.add_word("微信")
    path=trieCheck.get_bad_word("加骚女qq微信++：124041200")
    print(path)
    text=trieCheck.replace_bad_word("加骚女qq微信++：124041200")
    print(text)







