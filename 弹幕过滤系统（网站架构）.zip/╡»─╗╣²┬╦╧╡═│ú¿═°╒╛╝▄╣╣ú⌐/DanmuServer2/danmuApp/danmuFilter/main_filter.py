from danmuApp.danmuFilter.filter_prepare import FilterPrepare
from danmuApp.danmuFilter.ACTree import ACTree
import codecs
import time
import json
import os
class DanmuFilter(object):
    def __init__(self):
        self.acTree=ACTree()
        self.filter_prepare=FilterPrepare()
        self.dirtyDictionary={}
    def loads(self,path):
        with codecs.open(filename=path,mode='r',encoding='utf-8') as file:
            count=0
            for line in file.readlines():
                line=line.strip()
                count+=1
                self.dirtyDictionary[count]=line
                self.acTree.add_one_strmode(line)
        self.acTree.setFailPointer()
    def filter(self,text):
        filterPrepare_text=self.filter_prepare.filterPrepare(text)
        filterPath=self.acTree.runkmp(filterPrepare_text)
        filterInfo={}
        for i in filterPath:
            filterInfo[self.dirtyDictionary[i]]=filterPath[i]
        return filterInfo
if __name__== '__main__':
    danmuFilter=DanmuFilter()
    danmuFilter.loads('dirty_dict.txt')
    path=danmuFilter.filter("╅加騷女qq微信   ṎＭ習近平++? ?[]( )!!：12         4041200")
    #danmuFilter.filter("小骚女")
    print(path)