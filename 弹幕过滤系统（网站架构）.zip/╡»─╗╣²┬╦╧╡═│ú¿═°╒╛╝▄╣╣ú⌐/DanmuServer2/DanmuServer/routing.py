from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter,URLRouter
from danmuApp.routing import danmu_websocket_routing
application=ProtocolTypeRouter(
    {
        'websocket':AuthMiddlewareStack(
            URLRouter(danmu_websocket_routing+[])#使用+号连接两个列表
        )
    }
)